<!DOCTYPE html>
<html>
    <head>
        <title>form with password strength checker</title>
		<link rel="stylesheet" type="text/css" href="CSS/css.css"><!--Linking the style sheet -->
		<script src="JS/jquery-3.3.1.js"></script><!--Linking the jquery downloaded on the web -->
		<script src="js/Javascript.js"></script><!--Linking the javscript file with all the functions -->
    </head>
    <body>
          <!-- The heading-->
          <svg>
          <text y="30">Please play</text>
           <text y="80">with the form</text>
          </svg>
    
    <div id="outside">
    
    <form id="frm" >
    
    <!--the name-->
    <label>Your name:</label><br/>
    <input type="text" id="name" onblur="nm()" maxlength=30 size=30 placeholder="Your name .."/><br/>
    <!--name display-->
    <div id="di1" class="color"></div>
    
    <!-- the email-->
   <label>Email address:</label><br/>
   <input type="email" id="mail" size=30 placeholder="you@example.com" onblur="chkMail()" required/><br/>
   <div id="di2" class="color"></div>

    <!--the password-->
    <label>Enter a password:</label><br/>
    <input type="password" id="pass"size=30 oninput="chk()" placeholder="*******" /><br/><br/>
   <!--the bar -->
  <meter value="0" min="0" max="100" id="meter"></meter>
     <!--password display-->
  <div id="di3" class="color"></div>

  <!--phone number-->
 <label>phone number<b>(optional)</b></label><br/>
 <i>only checks for country code</i><br/>
  <input type="tel" min=4 max=12 id="tel1"size=30 onblur="num()"/><br/>
  <div id="di4" ></div> 
  <br/><br/>
   <input type="button" id="btn" value="Confirm Details" onclick="check()"/>
 </form>
<div>
    </body>
</html>