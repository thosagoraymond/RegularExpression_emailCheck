/**************
regular expression tuitorial

https://regexone.com/lesson/kleene_operators

************/

//it may not be the proper code its always trial and error
alert("This may not be the most beautiful code in the world it only domonstrates how regular expressions can come in handy \n \n suggestions are welcome ");
//for the input type name
function nm(){
       var e=document.getElementById("name").value;
         var di=document.getElementById("di1");
   //if the name has a digit
       if(e.match(/\d/)){
       di.innerHTML="Really does the name have a number";
   //its impossible to match regular expressions for name :)
       }else{
           di.innerHTML="How are you "+" "+e;
           di.style.color="gold";
           }
       }
   //for the password strength
   function chk(){
   //the display beneath
var p=document.getElementById("di3");

//get the password
var c=document.getElementById("pass").value;
//get the bar
var m=document.getElementById("meter");

//starts with an alpha-numeric x-ter,letter or digit
if(c.match(/\W+|[a-zA-Z0-9][a-zA-Z0-9]+/)){
    m.style.visibility="visible";
 m.value=20; 
   p.innerHTML="worse";
}else{
    m.value="";
    p.innerHTML="";
    m.style.visibility="hidden";
}
if(c.match(/[0-9]/)){
    m.value=40;
    p.innerHTML="weak";
    }
 
        if(c.match(/[!@£$\%^&*()]+/)){
    m.value=60;
    p.innerHTML="fair";
    }
  if(c.match(/[~<#>?]+/)){
    m.value=100;
    p.innerHTML="strong";
}
if(c.match(/[¶∆√¢€¥®©™°•¬π]/)){
m.value="";
alert("the password has character(s) not allowed ");
}
    }
    //check if everything is empty
    //I dont know why i keep calling the IDs everywhere
    function check(){
   c=document.getElementById("pass").value;
   var p=document.getElementById("di3");
   var e=document.getElementById("name").value;
   var h=document.getElementById("mail").value;
   var y=document.getElementById("di2");

var di1=document.getElementById("di1");
if(h==""){
    y.innerHTML="Email is empty";
}
    if(c==""){
        p.innerHTML="Password is empty";
       
    }else if(c.length < 8){
        alert("thats a short password");
    }else{
        alert("correct ☑✅✅ '\n' 100,000XP! added");
        }
    if(e==""){
        di1.innerHTML="name is empty";
    }
    
}
//check country code
    function num(){
    var t=document.getElementById("tel1").value;
    var u=document.getElementById("di4"); 
    //start with a plus sign followed by a bracket(optional)then [0-9] {3}times each close bracket(optional) then match some white spaces(\s) (optional)?
    var exp=/^[\+][(]?[0-9]{3}[)]?[-\s\.]?/;
    if(exp.test(t)==true){
        u.innerHTML="&#9989 &#9989";
        return true;
    }else if(isNaN(t)){
        u.innerHTML="please write  number(s)";
            }
    else{
        u.innerHTML="Please write the contry code";
    
        return false;
    }
}
//validate email
 
 function chkMail(){
    var regExp=/\S+@\S+\.\S+/;//( \S+  means atleast one non-space characters)
    
    var e=document.getElementById("mail").value;
       var f=document.getElementById("di2");
    if(regExp.test(e)==true){
     
        f.innerHTML="&#9989 &#9989";//tick icon
                return true;
    }else if(e==""){
        f.innerHTML="please fill in this field";
    }else{
        f.innerHTML="please use correct email format eg you123@them.hi";
        return false;
        }  
}
 